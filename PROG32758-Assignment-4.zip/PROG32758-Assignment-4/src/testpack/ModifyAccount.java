package testpack;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ModifyAccount")
public class ModifyAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer uid = (Integer) request.getSession().getAttribute("uid");
		if(uid == null) {
			// not logged in, send to Login with error message
			response.sendRedirect("Login?msg=have to login first...");
		}
		else {
			// get to page ModifyAccount

			DB_Access db = new DB_Access();
			String lname=db.getLoginName(uid);
			String uname=db.getUserName(uid);
		
			request.setAttribute("lname",lname);
			request.setAttribute("uname",uname);
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/ModifyAccount.jsp");
			rd.forward(request, response);			
		}
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mlname = request.getParameter("mlname");
		String mname = request.getParameter("mname");
		String mpass1 = request.getParameter("mpass1");
		String mpass2 = request.getParameter("mpass2");
		String opass = request.getParameter("opass");
		Integer uid = (Integer) request.getSession().getAttribute("uid");
		//System.out.println(mlname + mname+ mPass1+mpass2+ uid);
		DB_Access db = new DB_Access();
		String originalPassword=db.getUserPassword(uid);
		User user=new User(uid,mlname,mname,mpass1,mpass2);
//	System.out.println(user.getLoginName()+"/n"+user.getLoginPass1()+"/n"+user.getName()+"/n "+user.getUid());
		int res= db.updateAccount(user);
		String msg="";
		if(opass.equals(originalPassword)) {
		if(res==0) {
			msg="Your Account has been modified successfully";
			response.sendRedirect("Home?"+msg);
		}
		else if(res==4) {
			msg="Unsuccessful attempt,Password and Confirm Password should be same";
			response.sendRedirect("ModifyAccount?msg="+msg);
		}
		else if(res==1) {
			msg="Input values are too long";
			response.sendRedirect("ModifyAccount?msg="+msg);
		}
		}
		else {
			msg="Incorrect old password";
			response.sendRedirect("ModifyAccount?msg="+msg);
		}
		
		
		
	}

}
