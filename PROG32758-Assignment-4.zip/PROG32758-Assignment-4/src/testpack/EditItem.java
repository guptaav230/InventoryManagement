package testpack;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EditItem")
public class EditItem extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer uid = (Integer) request.getSession().getAttribute("uid");
		if(uid == null) {
			// not logged in, send to Login with error message
			response.sendRedirect("Login?msg=have to login first...");
		}
		else {
			// get to page ModifyAccount
			DB_Access db = new DB_Access();
			int iid=Integer.parseInt(request.getParameter("id"));
			Item item=db.getItemDescription(iid);
			request.setAttribute("ItemName", item.getName());
			request.setAttribute("ItemQty", item.getQty());
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/ModifyItem.jsp");
			rd.forward(request, response);			
		}
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer uid = (Integer) request.getSession().getAttribute("uid");
		String itemName=request.getParameter("nitemName");
		int itemQty =Integer.parseInt(request.getParameter("nitemQty"));
		int iid=Integer.parseInt(request.getParameter("id"));
		Item item= new Item(iid,itemName,itemQty);
		DB_Access db = new DB_Access();
		int res=db.updateItem(item,uid);
		if(res==0) {
			response.sendRedirect("Home?"+"Item Modified Successfully");
		}
		else {
			response.sendRedirect("Home?"+"Unexpected error ocurred");
		}
		
	}

}
