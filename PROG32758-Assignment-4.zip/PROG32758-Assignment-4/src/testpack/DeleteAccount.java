package testpack;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/DeleteAccount")
public class DeleteAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer uid = (Integer) request.getSession().getAttribute("uid");
		if(uid == null) {
			// not logged in, send to Login with error message
			response.sendRedirect("Login?msg=have to login first...");
		}
		else {
			// get to page ModifyAccount
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/DeleteAccount.jsp");
			rd.forward(request, response);			
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String inputpassword = request.getParameter("lpass");
		Integer uid = (Integer) request.getSession().getAttribute("uid");
		DB_Access db = new DB_Access();
		String storedPassword=db.getUserPassword(uid);
		String userName=db.getUserName(uid);
		User user= new User(uid);
		if(inputpassword.equals(storedPassword)) {
			int res=db.deleteAccount(user);
			if(res==0) {
				response.sendRedirect("Login?"+"Your Account "+userName+"has been deleted successfully");
			}
			else {
				response.sendRedirect("Home?"+"Unsuccessful attempt, Account is still active");
			}
		}
		else {
			response.sendRedirect("DeleteAccount?"+"Incorrect Password");
		}

	}

}
