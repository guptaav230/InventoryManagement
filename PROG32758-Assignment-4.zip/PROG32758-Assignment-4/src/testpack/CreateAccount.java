package testpack;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CreateAccount")
public class CreateAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/CreateAccount.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String loginName=request.getParameter("lname");
		String userName=request.getParameter("uname");
		String password1=request.getParameter("lpass");
		String password2=request.getParameter("clpass");
		User u=new User(loginName,userName,password1,password2);
		DB_Access db = new DB_Access();
		int res=db.createUserAccount(u);
		if(res==0) {
			response.sendRedirect("Login?"+"msg=Account Created Successfully ,You can login now");
		}
		else if(res==1){
			response.sendRedirect("CreateAccount?"+"msg=Input Values too long");
		}
		else if(res==2) {
			response.sendRedirect("CreateAccount?"+"msg=This Login name already exist");
		}else if(res==3) {
			response.sendRedirect("CreateAccount?"+"msg=Empty field submitted");
		}else if(res==4) {
			response.sendRedirect("CreateAccount?"+"msg=Password and confirm Password must be same");
		}else {
			response.sendRedirect("Login?"+"unexpected error");
		}
		
		
	}

}
