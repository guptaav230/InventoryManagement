package testpack;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteItem")
public class DeleteItem extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer uid = (Integer) request.getSession().getAttribute("uid");
		if(uid == null) {
			// not logged in, send to Login with error message
			response.sendRedirect("Login?msg=have to login first...");
		}
		else {
			// get to page ModifyAccount
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/DeleteItem.jsp");
			rd.forward(request, response);			
		}
	
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer uid = (Integer) request.getSession().getAttribute("uid");
		String userChoice=request.getParameter("userChoice");
		int iid=Integer.parseInt(request.getParameter("id"));
		Item item=new Item(iid);
	//	System.out.println("userChoice:  "+userChoice);
		if(userChoice.equalsIgnoreCase("Yes")){
			DB_Access db = new DB_Access();
			int res=db.deleteItem(item,uid);
			
			if(res==0) {
				response.sendRedirect("Home?"+"Item Deleted Successfully");
			}
			else {
				response.sendRedirect("Home?"+"Unexpected error ocurred");
			}
			
		}else if(userChoice.equalsIgnoreCase("No")) {
			response.sendRedirect("Home");
		}
		else {
			response.sendRedirect("Home?"+"Unexpected error");
		}
	
	}

}
